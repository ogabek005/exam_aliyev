from .course_serializer import *
from .departament_serializer import *
from .group_serializer import *
from .login_serializer import *
from .student_serializer import *
from .teacher_serializer import *
from .user_serializer import *

